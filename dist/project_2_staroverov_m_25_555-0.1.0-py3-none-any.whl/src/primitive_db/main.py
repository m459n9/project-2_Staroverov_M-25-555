def main():
    print('DB project is running!')